package voice;

import javax.swing.JPanel;

public class BrowserPaneWindow extends JPanel{

	public BrowserPaneWindow(double height, double width) {
		
	}

	
}
